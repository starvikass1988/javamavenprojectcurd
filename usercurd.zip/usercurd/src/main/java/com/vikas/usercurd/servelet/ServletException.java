package com.vikas.usercurd.servelet;

public class ServletException extends Exception {

}
